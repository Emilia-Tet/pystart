# po przygotowaniu paczki: 
# komenda: python setup.py sdist

from setuptools import setup, find_packages

setup(name = 'pystart_sample',
      version = '0.0.1',
      description = 'sample description',
      author = 'EPT',
      packages = find_packages(exclude=['tests']))