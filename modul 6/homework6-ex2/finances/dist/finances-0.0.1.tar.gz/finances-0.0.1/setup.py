from setuptools import setup, find_packages

setup(
    name = 'finances',
    version = '0.0.1',
    description = 'sample_description',
    packages = find_packages(exclude=['*.tests', 'tests'])
)